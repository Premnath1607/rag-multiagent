"""Retrieval Agent: query embedding -> hybrid (dense + BM25) -> RRF -> cross-encoder -> top-k.

Permission filtering is applied INSIDE both searches, so unauthorised chunks never
become candidates (and never reach the LLM).
"""

import re
import time

from qdrant_client import models
from rank_bm25 import BM25Okapi

from app import config
from app.store import get_client, get_embeddings, get_reranker, with_retry


_keyword_cache: dict = {}  # (collection, tags) -> (BM25Okapi, points)


def tokenize(text: str) -> list[str]:
    return re.findall(r"\w+", text.lower())


def permission_filter(user_tags: list[str]) -> models.Filter:
    return models.Filter(
        must=[
            models.FieldCondition(
                key="access_tags",
                match=models.MatchAny(any=user_tags)
            )
        ]
    )


def invalidate_keyword_index(collection: str) -> None:
    for key in [k for k in _keyword_cache if k[0] == collection]:
        del _keyword_cache[key]


def _scroll_all(collection: str, flt: models.Filter):
    client = get_client()
    points = []
    offset = None

    while True:
        batch, offset = client.scroll(
            collection,
            scroll_filter=flt,
            limit=256,
            offset=offset,
            with_payload=True,
            with_vectors=False,
        )

        points.extend(batch)

        if offset is None:
            return points


def _keyword_index(collection: str, user_tags: list[str]):
    key = (collection, tuple(sorted(user_tags)))

    if key not in _keyword_cache:
        pts = _scroll_all(
            collection,
            permission_filter(user_tags)
        )

        bm25 = (
            BM25Okapi(
                [tokenize(p.payload["text"]) for p in pts]
            )
            if pts
            else None
        )

        _keyword_cache[key] = (bm25, pts)

    return _keyword_cache[key]


def _to_chunk(point, score: float) -> dict:
    p = point.payload

    return {
        "id": str(point.id),
        "text": p["text"],
        "source": p.get("source"),
        "doc_id": p.get("doc_id"),
        "author": p.get("author"),
        "date": p.get("date"),
        "chunk_index": p.get("chunk_index"),
        "score": float(score),
    }


def retrieve(
    query: str,
    collection: str,
    user_tags: list[str],
    k: int = config.TOP_K,
    n: int = config.CANDIDATES,
    rerank: bool = True,
    mode: str = "hybrid",
) -> dict:
    """
    Retrieve relevant chunks.

    mode:
        "hybrid"  -> dense + BM25 + RRF
        "dense"   -> semantic/vector search only
        "keyword" -> BM25 keyword search only
    """

    client = get_client()
    timings = {}

    # ---------------------------------------------------------
    # Check collection
    # ---------------------------------------------------------

    if not client.collection_exists(collection):
        return {
            "chunks": [],
            "timings": timings,
        }

    flt = permission_filter(user_tags)

    # ---------------------------------------------------------
    # 1. Semantic / dense search
    # ---------------------------------------------------------

    dense = []

    if mode in ("hybrid", "dense"):
        t = time.perf_counter()

        qvec = with_retry(
            get_embeddings().embed_query,
            query,
        )

        dense = client.query_points(
            collection,
            query=qvec,
            query_filter=flt,
            limit=n,
            with_payload=True,
        ).points

        timings["dense_ms"] = round(
            (time.perf_counter() - t) * 1000,
            1,
        )

    # ---------------------------------------------------------
    # 2. Keyword / BM25 search
    # ---------------------------------------------------------

    keyword = []

    if mode in ("hybrid", "keyword"):
        t = time.perf_counter()

        bm25, pts = _keyword_index(
            collection,
            user_tags,
        )

        if bm25 is not None:
            scores = bm25.get_scores(
                tokenize(query)
            )

            order = sorted(
                range(len(pts)),
                key=lambda i: -scores[i],
            )[:n]

            keyword = [
                pts[i]
                for i in order
                if scores[i] > 0
            ]

        timings["keyword_ms"] = round(
            (time.perf_counter() - t) * 1000,
            1,
        )

    # ---------------------------------------------------------
    # 3. Reciprocal Rank Fusion (RRF)
    # ---------------------------------------------------------

    fused: dict = {}

    for ranked in (dense, keyword):
        for rank, point in enumerate(ranked):

            entry = fused.setdefault(
                str(point.id),
                [0.0, point],
            )

            # RRF score
            entry[0] += 1.0 / (60 + rank + 1)

    candidates = sorted(
        fused.values(),
        key=lambda x: -x[0],
    )[:n]

    # Nothing found
    if not candidates:
        return {
            "chunks": [],
            "timings": timings,
        }

    # ---------------------------------------------------------
    # 4. Cross-encoder reranking
    # ---------------------------------------------------------

    reranker = None

    if rerank:
        try:
            reranker = get_reranker()
        except Exception as exc:
            print(
                "[warn] Re-ranker unavailable, "
                f"continuing without it: {type(exc).__name__}: {exc}"
            )

    if reranker is not None:

        try:
            t = time.perf_counter()

            pts = [
                point
                for _, point in candidates
            ]

            pairs = [
                (
                    query,
                    point.payload["text"],
                )
                for point in pts
            ]

            ce_scores = reranker.predict(pairs)

            ranked = sorted(
                zip(ce_scores, pts),
                key=lambda x: -float(x[0]),
            )

            chunks = [
                _to_chunk(
                    point,
                    float(score),
                )
                for score, point in ranked[:k]
            ]

            timings["rerank_ms"] = round(
                (time.perf_counter() - t) * 1000,
                1,
            )

        except Exception as exc:

            # Reranker loaded but failed during prediction.
            # Fall back to RRF results.
            print(
                "[warn] Re-ranking failed, "
                f"continuing with RRF ranking: "
                f"{type(exc).__name__}: {exc}"
            )

            chunks = [
                _to_chunk(point, score)
                for score, point in candidates[:k]
            ]

            timings["rerank_ms"] = 0.0

    else:

        # -----------------------------------------------------
        # Reranker unavailable
        # Use RRF ranking directly
        # -----------------------------------------------------

        chunks = [
            _to_chunk(point, score)
            for score, point in candidates[:k]
        ]

        timings["rerank_ms"] = 0.0

    # ---------------------------------------------------------
    # Always return a dictionary
    # ---------------------------------------------------------

    return {
        "chunks": chunks,
        "timings": timings,
    }
