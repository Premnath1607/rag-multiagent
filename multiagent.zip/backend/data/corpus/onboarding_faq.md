# New Joiner FAQ

**Where do I collect my laptop?** Laptops are collected on your first day from the IT desk on floor 3, desk 3B.

**Will I have a buddy?** Yes, every new joiner is assigned an onboarding buddy for the first 30 days.

**What training is mandatory?** Security Awareness and Code of Conduct training must be completed within 14 days of joining.

**When is my probation review?** Probation lasts 90 days and ends with a review with your manager.
